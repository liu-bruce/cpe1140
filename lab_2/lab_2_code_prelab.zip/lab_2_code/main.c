#include "functions.h"

void main()
{
sum_of_resisitors();
}
