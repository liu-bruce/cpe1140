#ifndef functions
#define functions

void hello_world();
void sum_of_resisitors();
void source_current_series();
void voltage_divder();


#endif
