#include "functions.h"
#include <stdio.h>

void voltage_divder()
{
  double set_of_resistors [] = {470.0,
                                620.0,
                                1000.0},
         series_of_resistors = 2090,
         source_voltage = 5.0,
         voltage_target_resisitor = 0.0;


  for (int count = 0 ; count < 3 ; count++ )
  {
    voltage_target_resisitor = source_voltage * set_of_resistors[count]/series_of_resistors;
    printf("the expected voltage of %.3lf ohm resisitors is about %.3lf volts \n",
           set_of_resistors[count], voltage_target_resisitor
          );
  }

}

void source_current_series()
{
  double value_of_sum_of_resistors = 2090.000,
         source_voltage = 5.0,
         expected_current = 0.0;

         //v=iR
         //v/R = i
expected_current = source_voltage / value_of_sum_of_resistors;
printf("The expected current is about :%.3lf \n", expected_current);

}

void sum_of_resisitors()
{
  double set_of_resistors [] = {470.0,
                                620.0,
                                1000.0},
         series_of_resistors = 0.0;


         for(int count = 0; count < 3 ; count++)
         {
           series_of_resistors += set_of_resistors[count];
         }
  printf("The the sum of resisitors are : %.3lf\n",series_of_resistors);


}


void hello_world()
{
  printf("hello world");
}
